#include "Angel.h"
#include "Sphere.h"
#include <glm/glm.hpp>
#include <glm/ext.hpp>
#include <glm/gtc/matrix_transform.hpp>

typedef Angel::vec4 color4;

Sphere earth = Sphere(1.0f);

float scales[] = {1.0f, //earth 
                  0.33f, //mercury
                  0.75f, //venus
                  0.5f, //mars
                  11.0f, //jupiter
                  9.0f, //saturn
                  4.0f, //uranus
                  3.75f, //neptune
                  10.0f  //sun
};

// threshhold for objs to appear = 10.0f
float locations[] = { 20.0f, //earth 
                      12.0f, //mercury
                      15.0f, //venus
                      30.0f, //mars
                      50.0f, //jupiter
                      80.0f, //saturn
                      110.0f, //uranus
                      130.0f, //neptune
                      0.0f  //sun
};
color4 colors[] = {color4(0.333f, 0.333f, 0.941f, 1.0f), //earth
                   color4(0.761f, 0.761f, 0.761f, 1.0f), //mercury
                   color4(0.933f, 0.753f, 0.365f, 1.0f), //venus
                   color4(0.792f, 0.427f, 0.184f, 1.0f), //mars
                   color4(0.69f, 0.592f, 0.51f, 1.0f),  //jupiter
                   color4(0.749f, 0.71f, 0.604f, 1.0f), //saturn
                   color4(0.8f, 0.949f, 0.953f, 1.0f), //uranus
                   color4(0.145f, 0.38f, 0.725f, 1.0f), //neptune
                   color4(0.886f, 0.424f, 0.043f, 1.0f) //sun
};

GLuint vao, vbo, ibo, vPosition, modelAttrib, viewAttrib, projectionAttrib, colorAttrib;
glm::mat4 model;

glm::vec3 cameraPos, cameraTarget, cameraDirection, cameraRight, cameraUp, cameraFront;
glm::mat4 view, projection;

float speed = 10.0f, yaw = -90.0f, factor = 0.005f, rotate = 0.0f, orbit =0.0f;

void init() {
	// Create a vertex array object
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);

	// Create and initialize a vertex buffer object for earth
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, earth.getInterleavedVertexSize(), earth.getInterleavedVertices(), GL_STATIC_DRAW);

    // Create and initialize an index buffer object for earth
    glGenBuffers(1, &ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, earth.getIndexSize(), earth.getIndices(), GL_STATIC_DRAW);
    // Load shaders and use the resulting shader program
    GLuint program = InitShader("vshader.glsl", "fshader.glsl");
    glUseProgram(program);

	// set up vertex arrays
    vPosition = glGetAttribLocation(program, "vertexPosition");
    glEnableVertexAttribArray(vPosition);

    modelAttrib = glGetUniformLocation(program, "model");
    viewAttrib = glGetUniformLocation(program, "view");
    projectionAttrib = glGetUniformLocation(program, "projection");
    colorAttrib = glGetUniformLocation(program, "color");

	//camera code
    cameraPos = glm::vec3(0.0f, 0.0f, 300.0f);
    cameraTarget = glm::vec3(0.0f, 0.0f, 0.0f);
    cameraDirection = glm::normalize(cameraPos - cameraTarget);
    cameraRight = glm::normalize(glm::cross(glm::vec3(0.0f, 1.0f, 0.0f), cameraDirection));
    cameraUp = glm::cross(cameraDirection, cameraRight);
    cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);

    projection = glm::perspective(glm::radians(45.f), 512.0f / 512.0f, 0.1f, 900.0f);
    glUniformMatrix4fv(projectionAttrib, 1, GL_FALSE, glm::value_ptr(projection));
	
    glEnable(GL_DEPTH_TEST);
	glClearColor(0.0, 0.0, 0.0, 0.0);
}


void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
    glUniformMatrix4fv(viewAttrib, 1, GL_FALSE, glm::value_ptr(view));
    
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, earth.getInterleavedStride(), BUFFER_OFFSET(0));

    for (int i = 0; i < 9; i++) {
        model = glm::mat4(1.0f);
        model = glm::rotate(model, glm::radians(rotate), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::translate(model, glm::vec3(locations[i], 0.0f, 0.0f));
        model = glm::scale(model, glm::vec3(scales[i], scales[i], scales[i]));
        model = glm::rotate(model, glm::radians(orbit), glm::vec3(0.0f, 1.0f, 0.0f));
        glUniformMatrix4fv(modelAttrib, 1, GL_FALSE, glm::value_ptr(model));

        glUniform4fv(colorAttrib, 1, colors[i]);

        glDrawElements(GL_TRIANGLES, earth.getIndexCount(), GL_UNSIGNED_INT, 0);
    }


	glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 033:
        exit(EXIT_SUCCESS);
        break;
    case 'r':
        cameraPos += speed * cameraUp;
        break;
    case 'f':
        cameraPos -= speed * cameraUp;
        break;
    case 'w':
        cameraPos += speed * cameraFront;
        break;
    case 's':
        cameraPos -= speed * cameraFront;
        break;
    case 'a':
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * speed;
        break;
    case 'd':
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * speed;
        break;
    case 'q':
        yaw -= 1.0f;
        cameraDirection.x = glm::cos(glm::radians(yaw));
        cameraDirection.z = glm::sin(glm::radians(yaw));
        cameraFront = glm::normalize(cameraDirection);
        break;
    case 'e':
        yaw += 1.0f;
        cameraDirection.x = glm::cos(glm::radians(yaw));
        cameraDirection.z = glm::sin(glm::radians(yaw));
        cameraFront = glm::normalize(cameraDirection);
        break;
    }
}

void idle(void)
{
    rotate += factor;
    orbit += factor;

    if (rotate > 360.0f || orbit > 360.0f) {
        rotate = 0.0f;
        orbit = 0.0f;
    }


    glutPostRedisplay();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA);
	glutInitWindowSize(1024, 1024);
	glutInitContextVersion(3, 2);
	glutInitContextProfile(GLUT_CORE_PROFILE);
	glutCreateWindow("Solar System");
	
    glewInit();
    init();

	glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
	return 0;
}