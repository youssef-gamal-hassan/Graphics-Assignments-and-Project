#include "Angel.h"
#include "Sphere.h"
#include <glm/glm.hpp>
#include <glm/ext.hpp>
#include <glm/gtc/matrix_transform.hpp>

typedef Angel::vec4 point4, color4;

Sphere earth = Sphere(1.0f);

float scales[] = { 
                  10.0f,  //sun
                  1.0f, //earth 
                  0.33f, //mercury
                  0.75f, //venus
                  0.5f, //mars
                  11.0f, //jupiter
                  9.0f, //saturn
                  4.0f, //uranus
                  3.75f, //neptune
};

// threshhold for objs to appear = 10.0f

float locations[] = { 
                      0.0f,  //sun
                      20.0f, //earth 
                      12.0f, //mercury
                      15.0f, //venus
                      30.0f, //mars
                      50.0f, //jupiter
                      80.0f, //saturn
                      110.0f, //uranus
                      130.0f //neptune
};


GLuint vao, vbo, ibo, vPosition, modelAttrib, viewAttrib, projectionAttrib, program, cameraUniform;
glm::mat4 model;

glm::vec3 cameraPos, cameraTarget, cameraDirection, cameraRight, cameraUp, cameraFront;
glm::mat4 view, projection;

float speed = 10.0f, yaw = -90.0f, factor = 0.005f, rotate = 0.0f, orbit =0.0f;



void initLight()
{
    point4 light_poisiton1(15.f, 0.f, 0.f, 0.f);  // point light 1 
    point4 light_poisiton2(-15.f, 0.f, 0.f, 0.f);  // point light 2

    color4 light_ambient(0.5, 0.5, 0.5, 1.0);
    color4 light_diffuse(1.0, 1.0, 0.0, 1.0);
    color4 light_specular(1.0, 1.0, 1.0, 1.0);

    float light_constant = 1.f;
    float light_linear = 0.027f;
    float light_quadratic = 0.0028f;

    float material_shininess = 100.f;
    color4 material_ambient(0.5, 0.5, 0.5, 1.0);
    color4 material_diffuse(1.0, 1.0, 1.0, 1.0);
    color4 material_specular(1.0, 1.0, 1.0, 1.0);


    glUniform1f(glGetUniformLocation(program, "pointLights[0].constant"), light_constant);
    glUniform1f(glGetUniformLocation(program, "pointLights[0].linear"), light_linear);
    glUniform1f(glGetUniformLocation(program, "pointLights[0].quadratic"), light_quadratic);
    glUniform4fv(glGetUniformLocation(program, "pointLights[0].ambient"), 1, light_ambient);
    glUniform4fv(glGetUniformLocation(program, "pointLights[0].diffuse"), 1, light_diffuse);
    glUniform4fv(glGetUniformLocation(program, "pointLights[0].specular"), 1, light_specular);
    glUniform4fv(glGetUniformLocation(program, "pointLights[0].position"), 1, light_poisiton1);

    glUniform1f(glGetUniformLocation(program, "pointLights[1].constant"), light_constant);
    glUniform1f(glGetUniformLocation(program, "pointLights[1].linear"), light_linear);
    glUniform1f(glGetUniformLocation(program, "pointLights[1].quadratic"), light_quadratic);
    glUniform4fv(glGetUniformLocation(program, "pointLights[1].ambient"), 1, light_ambient);
    glUniform4fv(glGetUniformLocation(program, "pointLights[1].diffuse"), 1, light_diffuse);
    glUniform4fv(glGetUniformLocation(program, "pointLights[1].specular"), 1, light_specular);
    glUniform4fv(glGetUniformLocation(program, "pointLights[1].position"), 1, light_poisiton2);

    glUniform4fv(glGetUniformLocation(program, "material.ambient"), 1, material_ambient);
    glUniform4fv(glGetUniformLocation(program, "material.diffuse"), 1, material_diffuse);
    glUniform4fv(glGetUniformLocation(program, "material.specular"), 1, material_specular);
    glUniform1f(glGetUniformLocation(program, "material.shininess"), material_shininess);
}

void init() {
	// Create a vertex array object
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);

	// Create and initialize a vertex buffer object for earth
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, earth.getInterleavedVertexSize(), earth.getInterleavedVertices(), GL_STATIC_DRAW);

    // Create and initialize an index buffer object for earth
    glGenBuffers(1, &ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, earth.getIndexSize(), earth.getIndices(), GL_STATIC_DRAW);
    // Load shaders and use the resulting shader program
    program = InitShader("vshader.glsl", "fshader.glsl");
    glUseProgram(program);

	// set up vertex arrays
    vPosition = glGetAttribLocation(program, "vertexPosition");
    glEnableVertexAttribArray(vPosition);

    modelAttrib = glGetUniformLocation(program, "model");
    viewAttrib = glGetUniformLocation(program, "view");
    projectionAttrib = glGetUniformLocation(program, "projection");
    cameraUniform = glGetUniformLocation(program, "camera");


	//camera code
    cameraPos = glm::vec3(0.0f, 0.0f, 300.0f);
    cameraTarget = glm::vec3(0.0f, 0.0f, 0.0f);
    cameraDirection = glm::normalize(cameraPos - cameraTarget);
    cameraRight = glm::normalize(glm::cross(glm::vec3(0.0f, 1.0f, 0.0f), cameraDirection));
    cameraUp = glm::cross(cameraDirection, cameraRight);
    cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);

    projection = glm::perspective(glm::radians(45.f), 512.0f / 512.0f, 0.1f, 900.0f);
    glUniformMatrix4fv(projectionAttrib, 1, GL_FALSE, glm::value_ptr(projection));
	
    initLight();

    glEnable(GL_DEPTH_TEST);
	glClearColor(0.0, 0.0, 0.0, 0.0);
}


void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
    glUniformMatrix4fv(viewAttrib, 1, GL_FALSE, glm::value_ptr(view));
    glUniform3fv(cameraUniform, 1, glm::value_ptr(cameraPos));

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, earth.getInterleavedStride(), BUFFER_OFFSET(0));

    for (int i = 0; i < 9; i++) {
        model = glm::mat4(1.0f);
        model = glm::rotate(model, glm::radians(rotate), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::translate(model, glm::vec3(locations[i], 0.0f, 0.0f));
        model = glm::scale(model, glm::vec3(scales[i], scales[i], scales[i]));
        model = glm::rotate(model, glm::radians(orbit), glm::vec3(0.0f, 1.0f, 0.0f));
        glUniformMatrix4fv(modelAttrib, 1, GL_FALSE, glm::value_ptr(model));


        glDrawElements(GL_TRIANGLES, earth.getIndexCount(), GL_UNSIGNED_INT, 0);
    }


	glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 033:
        exit(EXIT_SUCCESS);
        break;
    case 'r':
        cameraPos += speed * cameraUp;
        break;
    case 'f':
        cameraPos -= speed * cameraUp;
        break;
    case 'w':
        cameraPos += speed * cameraFront;
        break;
    case 's':
        cameraPos -= speed * cameraFront;
        break;
    case 'a':
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * speed;
        break;
    case 'd':
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * speed;
        break;
    case 'q':
        yaw -= 1.0f;
        cameraDirection.x = glm::cos(glm::radians(yaw));
        cameraDirection.z = glm::sin(glm::radians(yaw));
        cameraFront = glm::normalize(cameraDirection);
        break;
    case 'e':
        yaw += 1.0f;
        cameraDirection.x = glm::cos(glm::radians(yaw));
        cameraDirection.z = glm::sin(glm::radians(yaw));
        cameraFront = glm::normalize(cameraDirection);
        break;
    }
}

void idle(void)
{
    rotate += factor;
    orbit += factor;

    if (rotate > 360.0f || orbit > 360.0f) {
        rotate = 0.0f;
        orbit = 0.0f;
    }


    glutPostRedisplay();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA);
	glutInitWindowSize(1024, 1024);
	glutInitContextVersion(3, 2);
	glutInitContextProfile(GLUT_CORE_PROFILE);
	glutCreateWindow("Solar System");
	
    glewInit();
    init();

	glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
	return 0;
}